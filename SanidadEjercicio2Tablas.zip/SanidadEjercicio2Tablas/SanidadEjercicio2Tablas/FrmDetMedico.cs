﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SanidadEjercicio2Tablas.DAO;
using SanidadEjercicio2Tablas.Modelo;

namespace SanidadEjercicio2Tablas
{
    public partial class FrmDetMedico : Form
    {
        private MedicoDAO mDAO;
        private HospitalDAO hDAO;
        private Medico m;
        public int id;

        public FrmDetMedico()
        {
            InitializeComponent();
            mDAO = new MedicoDAO();
            hDAO = new HospitalDAO();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void FrmDetMedico_Load(object sender, EventArgs e)
        {
            CenterToScreen();
            cargarComboHospitales();
            if (id > 0)
            {
                m = mDAO.leerUno(id);
                numID.Text = id.ToString();
                txtNombre.Text = m.Nombre;
                cboEspecialidad.Text = m.Especialidad.ToString();
                txtDireccion.Text = m.Direccion.ToString();
                dtpFechaIncorporacion.Text = m.FechaIncorporacion.ToString();
                txtActivo.Text = m.Activo.ToString();
                Hospital h = m.Hospital;
                cboHospital.SelectedItem = h.Nombre.ToString();
            }
            else 
            {
                numID.Value = 0;
                txtNombre.Clear();
                cboEspecialidad.SelectedIndex = -1;
                txtDireccion.Clear();
                txtActivo.Clear();
                cboHospital.SelectedIndex = -1;
                
            }
        }

        public void cargarComboHospitales()
        {
            HospitalDAO hDAO = new HospitalDAO();
            List<String> lhosp;
            lhosp = hDAO.consultarHospitalesCbo();
            cboHospital.DataSource = lhosp;
            //cboCategoria.SelectedIndex;
            //cboCategoria.SelectedItem;
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        { 

            try
            {
                // Crear un objeto Medico con los valores de los controles del formulario
                m = new Medico
                {
                    Nombre = txtNombre.Text.Trim(),
                    Especialidad = cboEspecialidad.SelectedItem.ToString(),
                    Direccion = txtDireccion.Text.Trim(),
                    FechaIncorporacion = dtpFechaIncorporacion.Value,
                    Activo = txtActivo.Text.Trim().Equals("Si", StringComparison.OrdinalIgnoreCase)
                };

                // Asignar el hospital seleccionado
                string hospital = cboHospital.SelectedItem.ToString();
                m.Hospital = new Hospital(hDAO.leerIdHospitalPorNombre(hospital), hospital);

                // Si el id es mayor que 0, es una modificación
                if (id > 0)
                {
                    m.Id = getIdIfExist();
                    if (m.Id == -1)
                    {
                        MessageBox.Show("Error: ID de médico no válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Intentar modificar el médico
                    if (mDAO.modificarMedicos(m) > 0)
                    {
                        MessageBox.Show("Médico modificado correctamente.");
                    }
                    else
                    {
                        MessageBox.Show("Error al modificar médico.");
                    }
                }
                else
                {
                    // Si el id es 0 o no existe, es un alta de nuevo médico
                    if (mDAO.agregarMedico(m) > 0)
                    {
                        MessageBox.Show("Alta de médico correcta.");
                    }
                    else
                    {
                        MessageBox.Show("Error en el alta del médico.");
                    }
                }
            }
            catch (Exception ex)
            {
                // Captura cualquier excepción no prevista
                MessageBox.Show("Error inesperado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Close();
            }
        }

        private int getIdIfExist()
        {
            if (!numID.Text.Trim().Equals(""))
            {
                if (int.TryParse(numID.Text.Trim(), out int id))
                    return id;
                else
                    return -1;
            }
            else
                return -1;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
