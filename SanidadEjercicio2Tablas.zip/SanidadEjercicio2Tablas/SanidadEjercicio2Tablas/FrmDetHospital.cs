﻿using SanidadEjercicio2Tablas.DAO;
using SanidadEjercicio2Tablas.Modelo;
using System;
using System.Windows.Forms;

namespace SanidadEjercicio2Tablas
{
    public partial class FrmDetHospital : Form
    {
        private HospitalDAO hDAO = new HospitalDAO();
        private Hospital hos;
        public int id;

        public FrmDetHospital()
        {
            InitializeComponent();
        }

        private void FrmDetHospital_Load(object sender, EventArgs e)
        {
            CenterToScreen();

            if (id > 0)
            {
                hos = hDAO.leerHospitalPorId(id);

                if (hos != null)
                {
                    numID.Text = id.ToString();
                    txtNombre.Text = hos.Nombre;
                    txtPoblacion.Text = hos.Poblacion;
                    txtProvincia.Text = hos.Provincia;
                }
                else
                {
                    MessageBox.Show("Error: No se encontró el hospital con el ID proporcionado.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Close();
                }
            }
            else
            {
                numID.Value = 0;
                txtNombre.Clear();
                txtPoblacion.Clear();
                txtProvincia.Clear();
            }
        }

        private void btnAceptar_Click(object sender, EventArgs e)
        {
            if (!ValidarCampos())
            {
                MessageBox.Show("Todos los campos son obligatorios.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                hos = new Hospital
                {
                    Nombre = txtNombre.Text.Trim(),
                    Poblacion = txtPoblacion.Text.Trim(),
                    Provincia = txtProvincia.Text.Trim()
                };

                if (id > 0)
                {
                    hos.Id = getIdIfExist();
                    if (hos.Id == -1)
                    {
                        MessageBox.Show("Error: ID de hospital no válido.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (hDAO.modificarHospital(hos) > 0)
                    {
                        MessageBox.Show("Hospital modificado correctamente.");
                    }
                    else
                    {
                        MessageBox.Show("Error al modificar hospital.");
                    }
                }
                else
                {
                    if (hDAO.agregarHospital(hos) > 0)
                    {
                        MessageBox.Show("Alta de hospital correcta.");
                    }
                    else
                    {
                        MessageBox.Show("Error en la alta del hospital.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error inesperado: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                Close();
            }
        }

        private bool ValidarCampos()
        {
            return !string.IsNullOrWhiteSpace(txtNombre.Text) &&
                   !string.IsNullOrWhiteSpace(txtPoblacion.Text) &&
                   !string.IsNullOrWhiteSpace(txtProvincia.Text);
        }

        private int getIdIfExist()
        {
            if (int.TryParse(numID.Text.Trim(), out int id))
                return id;

            return -1;
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
