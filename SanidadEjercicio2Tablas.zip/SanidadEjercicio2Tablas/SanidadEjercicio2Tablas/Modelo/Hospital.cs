﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanidadEjercicio2Tablas.Modelo
{
    internal class Hospital
    {
        private int id;
        private String nombre;
        private String poblacion;
        private String provincia;

        public Hospital()
        {
        }

        public Hospital(int id, string nombre)
        {
            this.id = id;
            this.nombre = nombre;
        }

        public Hospital(int id, string nombre, string poblacion, string provincia)
        {
            this.Id = id;
            this.Nombre = nombre;
            this.Poblacion = poblacion;
            this.Provincia = provincia;
        }

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Poblacion { get => poblacion; set => poblacion = value; }
        public string Provincia { get => provincia; set => provincia = value; }
    }
}
