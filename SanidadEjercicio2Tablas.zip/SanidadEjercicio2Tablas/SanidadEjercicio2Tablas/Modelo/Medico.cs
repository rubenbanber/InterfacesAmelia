﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SanidadEjercicio2Tablas.Modelo
{
    internal class Medico
    {
        private int id;
        private String nombre;
        private String especialidad;
        private String direccion;
        private DateTime fechaIncorporacion;
        private Boolean activo;
        private Hospital hospital;

        public Medico()
        {
        }

        public Medico(int id, string nombre, string especialidad, string direccion, DateTime fechaIncorporacion, bool activo, Hospital hospital)
        {
            this.id = id;
            this.nombre = nombre;
            this.especialidad = especialidad;
            this.direccion = direccion;
            this.fechaIncorporacion = fechaIncorporacion;
            this.activo = activo;
            this.hospital = hospital;
        }

        public int Id { get => id; set => id = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Especialidad { get => especialidad; set => especialidad = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        public DateTime FechaIncorporacion { get => fechaIncorporacion; set => fechaIncorporacion = value; }
        public bool Activo { get => activo; set => activo = value; }
        internal Hospital Hospital { get => hospital; set => hospital = value; }
    }
}
