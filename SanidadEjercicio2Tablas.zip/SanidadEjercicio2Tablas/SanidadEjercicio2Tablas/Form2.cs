﻿using SanidadEjercicio2Tablas.DAO;
using SanidadEjercicio2Tablas.Modelo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SanidadEjercicio2Tablas
{
    public partial class Form2 : Form
    {
        private HospitalDAO hDAO;
        private int id;
        private List<Hospital> lisHospital;
        public Form2()
        {
            InitializeComponent();
            hDAO = new HospitalDAO();
            lisHospital = new List<Hospital>();
            CargarListaHospitales();
        }

        private void dgvMedicos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow fila = dgvHospitales.Rows[e.RowIndex];
            id = Convert.ToInt32(fila.Cells["idHospital"].Value);

            if (dgvHospitales.Columns[e.ColumnIndex].Name == "Modificar")
            {
                //llamar a la ventana FrmDetCategoria
                FrmDetHospital Det = new FrmDetHospital();
                Det.id = id;
                Det.ShowDialog();
            }
            if (dgvHospitales.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                if (id == -1) return;
                if (MessageBox.Show("¿Desea eliminar el hospital?", "Eliminar Hospital", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    if (hDAO.eliminarHospital(id) != 0)
                    {
                        MessageBox.Show("Hospital eliminado con éxito.");
                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el hospital.");
                    }
                }
            }
            CargarListaHospitales();
        }

        private void btnAlta_Click(object sender, EventArgs e)
        {
            FrmDetHospital DetHospital = new FrmDetHospital();
            DetHospital.id = 0;
            DetHospital.ShowDialog();
            CargarListaHospitales();
        }

        private void CargarListaHospitales(string filtro = "")
        {
            dgvHospitales.AllowUserToAddRows = false;
            //1-VACIO DataGridView
            dgvHospitales.Rows.Clear();
            dgvHospitales.Refresh();

            //Cargo la lista con la select
            lisHospital = hDAO.consultarHospitales(filtro);

            for (int i = 0; i < lisHospital.Count(); i++)
            {
                dgvHospitales.Rows.Add(
                    lisHospital[i].Id,
                    lisHospital[i].Nombre,
                    lisHospital[i].Poblacion,
                    lisHospital[i].Provincia);
            }

        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

