﻿using MySql.Data.MySqlClient;
using SanidadEjercicio2Tablas.Conexion;
using SanidadEjercicio2Tablas.Modelo;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace SanidadEjercicio2Tablas.DAO
{
    internal class HospitalDAO
    {
        private ConexionBase conexion = new ConexionBase();

        public HospitalDAO()
        {
        }

        public int agregarHospital(Hospital hospital)
        {
            int resul = 0;
            string strINSERT = "INSERT INTO hospitales (nombre, poblacion, provincia) VALUES (@nombre, @poblacion, @provincia);";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strINSERT, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@nombre", hospital.Nombre));
                mCommand.Parameters.Add(new MySqlParameter("@poblacion", hospital.Poblacion));
                mCommand.Parameters.Add(new MySqlParameter("@provincia", hospital.Provincia));

                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error en la base de datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0; // Retorna 0 para indicar error
            }

            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }

        public int modificarHospital(Hospital hospital)
        {
            int resul = 0;
            string strUPDATE = "UPDATE hospitales " +
                               "SET nombre = @nombre, " +
                               "poblacion = @poblacion, " +
                               "provincia = @provincia " +
                               "WHERE idHospital = @id";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strUPDATE, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@nombre", hospital.Nombre));
                mCommand.Parameters.Add(new MySqlParameter("@poblacion", hospital.Poblacion));
                mCommand.Parameters.Add(new MySqlParameter("@provincia", hospital.Provincia));
                mCommand.Parameters.Add(new MySqlParameter("@id", hospital.Id));

                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error en la base de datos: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0; // Retorna 0 para indicar error
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }

        public int eliminarHospital(int id)
        {
            int resul = 0;
            string strDELETE = "DELETE FROM hospitales WHERE idHospital=@id";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strDELETE, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@id", id));
                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                ex.ToString();
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }

        public Hospital leerHospitalPorId(int id)
        {
            MySqlDataReader mReader = null;
            Hospital hospital = new Hospital();
            string strCONSULTA = "SELECT * FROM hospitales WHERE idHospital=@id";

            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@id", id));
                mReader = mCommand.ExecuteReader();
                while (mReader.Read())
                {
                    hospital.Id = mReader.GetInt32("idHospital");
                    hospital.Nombre = mReader.GetString("nombre");
                    hospital.Poblacion = mReader.GetString("poblacion");
                    hospital.Provincia = mReader.GetString("provincia");
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                ex.ToString();
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return hospital;
        }

        public int leerIdHospitalPorNombre(string nombre)
        {
            MySqlDataReader mReader = null;
            string strCONSULTA = "SELECT idHospital FROM hospitales WHERE nombre=@nombre";
            int idHospital = 0;
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA, conexion.abrirConexion());
                mCommand.Parameters.Add(new MySqlParameter("@nombre", nombre));
                mReader = mCommand.ExecuteReader();
                while (mReader.Read())
                {
                    idHospital = mReader.GetInt32("idHospital");
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                ex.ToString();
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return idHospital;
        }

        public List<Hospital> consultarHospitales(string filtro)
        {
            List<Hospital> listaHospitales = new List<Hospital>();
            MySqlDataReader mReader = null;
            string strCONSULTA = "SELECT * FROM hospitales";

            if (!string.IsNullOrEmpty(filtro))
            {
                strCONSULTA += " WHERE " +
                               "nombre LIKE '%" + filtro + "%' OR " +
                               "direccion LIKE '%" + filtro + "%';";
            }

            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA, conexion.abrirConexion());
                mReader = mCommand.ExecuteReader();

                while (mReader.Read())
                {
                    Hospital hospital = new Hospital();
                    hospital.Id = mReader.GetInt32("idHospital");
                    hospital.Nombre = mReader.GetString("nombre");
                    hospital.Poblacion = mReader.GetString("poblacion");
                    hospital.Provincia = mReader.GetString("provincia");
                    listaHospitales.Add(hospital);
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                ex.ToString();
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return listaHospitales;
        }

        public List<String> consultarHospitalesCbo()
        {
            List<String> lisHospitales = new List<String>();
            MySqlDataReader mReader = null;
            string strCONSULTA = "SELECT * FROM hospitales";

            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA);
                mCommand.Connection = conexion.abrirConexion();
                mReader = mCommand.ExecuteReader();

                while (mReader.Read())
                {
                    lisHospitales.Add(mReader.GetString("nombre"));
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                ex.ToString();
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return lisHospitales;
        }
    }
}
