﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using SanidadEjercicio2Tablas.Conexion;
using SanidadEjercicio2Tablas.Modelo;

namespace SanidadEjercicio2Tablas.DAO
{
    internal class MedicoDAO
    {
        private ConexionBase conexion = new ConexionBase();
        
        public MedicoDAO() { }

        public int agregarMedico(Medico med)
        {
            int resul = 0;
            string strINSERT = "INSERT INTO medicos (nombre, especialidad, direccion, fecha_incorporacion, activo, idHospital) values (@nombre, @especialidad, @direccion, @fechaIncorporacion, @activo, @hospital);";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strINSERT, conexion.abrirConexion());
                mCommand.Parameters.AddWithValue("@nombre", med.Nombre);
                mCommand.Parameters.AddWithValue("@especialidad", med.Especialidad);
                mCommand.Parameters.AddWithValue("@direccion", med.Direccion);
                mCommand.Parameters.AddWithValue("@fechaIncorporacion", med.FechaIncorporacion);
                mCommand.Parameters.AddWithValue("@activo", med.Activo);
                mCommand.Parameters.AddWithValue("@hospital", med.Hospital.Id);
                
                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }

        public int modificarMedicos(Medico med)
        {
            int resul = 0;
            string strUPDATE = "UPDATE medicos " +
                "SET nombre = @nombre, " +
                "especialidad = @especialidad, " +
                "direccion = @direccion, " +
                "fecha_incorporacion = @fechaIncorporacion, " +
                "activo = @activo, " +
                "idHospital = @idHospital " +
                "WHERE idMedico = @id";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strUPDATE, conexion.abrirConexion());
                mCommand.Parameters.AddWithValue("@nombre", med.Nombre);
                mCommand.Parameters.AddWithValue("@especialidad", med.Especialidad);
                mCommand.Parameters.AddWithValue("@direccion", med.Direccion);
                mCommand.Parameters.AddWithValue("@fechaIncorporacion", med.FechaIncorporacion);
                mCommand.Parameters.AddWithValue("@activo", med.Activo);
                mCommand.Parameters.AddWithValue("@idHospital", med.Hospital.Id);
                mCommand.Parameters.AddWithValue("@id", med.Id);
                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }

        public int eliminarMedico(int id)
        {
            int resul = 0;
            string strDELETE = "DELETE FROM medicos WHERE idMedico=@id";
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strDELETE, conexion.abrirConexion());
                mCommand.Parameters.AddWithValue("@id", id);
                resul = mCommand.ExecuteNonQuery();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return resul;
        }

        public Medico leerUno(int id)
        {
            MySqlDataReader mReader = null;
            Medico m = new Medico();
            string strCONSULTA = "SELECT m.*, h.nombre as nombrehospital FROM medicos m INNER JOIN hospitales h ON h.idHospital = m.idHospital WHERE m.idMedico = @id";

            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA);
                mCommand.Parameters.AddWithValue("@id", id);
                mCommand.Connection = conexion.abrirConexion();
                mReader = mCommand.ExecuteReader();

                while (mReader.Read())
                {
                    m.Id = mReader.GetInt16("idMedico");
                    m.Nombre = mReader.GetString("nombre");
                    m.Especialidad = mReader.GetString("especialidad");
                    m.Direccion = mReader.GetString("direccion");
                    m.FechaIncorporacion = mReader.GetDateTime("fecha_incorporacion");
                    m.Activo = mReader.GetBoolean("activo");
                    Hospital h = new Hospital(mReader.GetInt16("idHospital"), mReader.GetString("nombrehospital"));
                    m.Hospital = h;
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return m;
        }

        public List<Medico> consultarMedico(string filtro)
        {
            List<Medico> lisMedico = new List<Medico>();
            MySqlDataReader mReader = null;
            Medico m;
            string strCONSULTA = "SELECT m.*, h.nombre as nombrehospital FROM medicos m INNER JOIN hospitales h ON h.idHospital = m.idHospital";
            if (filtro != "")
            {
                strCONSULTA += " WHERE " + "nombre LIKE '%" + filtro + "%' OR " + 
                    "direccion LIKE '%" + filtro + "%' OR " + 
                    "activo LIKE '%" + filtro + "%';";
            }
            try
            {
                MySqlCommand mCommand = new MySqlCommand(strCONSULTA);
                mCommand.Connection = conexion.abrirConexion();
                mReader = mCommand.ExecuteReader();

                while (mReader.Read())
                {
                    m = new Medico();
                    m.Id = mReader.GetInt16("idMedico");
                    m.Nombre = mReader.GetString("nombre");
                    m.Especialidad = mReader.GetString("especialidad");
                    m.Direccion = mReader.GetString("direccion");
                    m.FechaIncorporacion = mReader.GetDateTime("fecha_incorporacion");
                    m.Activo = mReader.GetBoolean("activo");
                    m.Hospital = new Hospital(mReader.GetInt16("idHospital"), mReader.GetString("nombrehospital"));
                    lisMedico.Add(m);
                }
                mReader.Close();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conexion.cerrarConexion();
            }
            return lisMedico;
        }
    }
}
