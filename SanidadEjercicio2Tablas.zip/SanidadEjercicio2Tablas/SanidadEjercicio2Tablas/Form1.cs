﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using SanidadEjercicio2Tablas.DAO;
using SanidadEjercicio2Tablas.Modelo;

namespace SanidadEjercicio2Tablas
{
    public partial class Form1 : Form
    {
        private MedicoDAO mDAO;
        private List<Medico> listaMedicos;
        private int idMedico = 0;
        public Form1()
        {
            InitializeComponent();
            mDAO = new MedicoDAO();
            listaMedicos = new List<Medico>();
            CargarListaMedicos();
        }

        private void btnAlta_Click(object sender, EventArgs e)
        {
            FrmDetMedico DetMedico = new FrmDetMedico();
            DetMedico.id = 0;
            DetMedico.ShowDialog();
            CargarListaMedicos();
        }

        private void CargarListaMedicos(string filtro = "")
        {
            dgvMedicos.AllowUserToAddRows = false;
            //VACIO DataGridView
            dgvMedicos.Rows.Clear();
            dgvMedicos.Refresh();
            //Cargo la lista con la select
            listaMedicos = mDAO.consultarMedico(filtro);

            for (int i = 0; i < listaMedicos.Count(); i++)
            {

                dgvMedicos.Rows.Add(
                    listaMedicos[i].Id,
                    listaMedicos[i].Nombre,
                    listaMedicos[i].Especialidad,
                    listaMedicos[i].Direccion,
                    listaMedicos[i].FechaIncorporacion.ToString("yyyy-MM-dd"), // Formateado para mejor visualización
                    listaMedicos[i].Activo ? "Sí" : "No", // Convierte booleano en texto legible
                    listaMedicos[i].Hospital.Nombre);
            }
        }

        private void btnVolver_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dgvMedicos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow fila = dgvMedicos.Rows[e.RowIndex];
            idMedico = Convert.ToInt32(fila.Cells["Id"].Value);

            if (dgvMedicos.Columns[e.ColumnIndex].Name == "Modificar")
            {
                //llamar a la ventana FrmDetCategoria
                FrmDetMedico Det = new FrmDetMedico();
                Det.id = idMedico;
                Det.ShowDialog();
            }

            if (dgvMedicos.Columns[e.ColumnIndex].Name == "Eliminar")
            {
                if (idMedico == -1) return;
                if (MessageBox.Show("¿Desea eliminar el medico?", "Eliminar medico", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    if (mDAO.eliminarMedico(idMedico) != 0)
                    {
                        MessageBox.Show("Medico eliminado con éxito.");

                    }
                    else
                    {
                        MessageBox.Show("Error al eliminar el medico.");
                    }
                }
            }
            CargarListaMedicos();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            CargarListaMedicos();
        }

        private void btnRefrescar_Click(object sender, EventArgs e)
        {
            CargarListaMedicos();
        }
    }
}
