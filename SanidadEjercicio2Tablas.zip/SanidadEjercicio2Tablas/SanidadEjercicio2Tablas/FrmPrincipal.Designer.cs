﻿namespace SanidadEjercicio2Tablas
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pnFormularios = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnMedicos = new System.Windows.Forms.Button();
            this.btnHospitales = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.pnFormularios.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.RoyalBlue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1282, 58);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(330, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Sanidad Castilla y León";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.MidnightBlue;
            this.panel2.Controls.Add(this.btnSalir);
            this.panel2.Controls.Add(this.btnMedicos);
            this.panel2.Controls.Add(this.btnHospitales);
            this.panel2.Location = new System.Drawing.Point(-2, 58);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(201, 607);
            this.panel2.TabIndex = 1;
            // 
            // pnFormularios
            // 
            this.pnFormularios.BackColor = System.Drawing.Color.LightBlue;
            this.pnFormularios.Controls.Add(this.pictureBox1);
            this.pnFormularios.Location = new System.Drawing.Point(199, 58);
            this.pnFormularios.Name = "pnFormularios";
            this.pnFormularios.Size = new System.Drawing.Size(1081, 607);
            this.pnFormularios.TabIndex = 2;
            this.pnFormularios.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::SanidadEjercicio2Tablas.Properties.Resources.png_clipart_pulse_computer_icons_heart_physician_medicine_heart_love_blue_removebg_preview__1_;
            this.pictureBox1.Location = new System.Drawing.Point(313, 169);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(493, 295);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnSalir
            // 
            this.btnSalir.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnSalir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSalir.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSalir.Image = global::SanidadEjercicio2Tablas.Properties.Resources.logout__1_;
            this.btnSalir.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSalir.Location = new System.Drawing.Point(3, 310);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(198, 55);
            this.btnSalir.TabIndex = 2;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = false;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnMedicos
            // 
            this.btnMedicos.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnMedicos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnMedicos.Font = new System.Drawing.Font("Microsoft YaHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMedicos.Image = global::SanidadEjercicio2Tablas.Properties.Resources.pngtree_young_doctor_drawing_coloring_pages_for_kids_png_image_9180950__1_;
            this.btnMedicos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnMedicos.Location = new System.Drawing.Point(3, 188);
            this.btnMedicos.Name = "btnMedicos";
            this.btnMedicos.Size = new System.Drawing.Size(198, 55);
            this.btnMedicos.TabIndex = 0;
            this.btnMedicos.Text = "Medicos";
            this.btnMedicos.UseVisualStyleBackColor = false;
            this.btnMedicos.Click += new System.EventHandler(this.btnMedicos_Click);
            // 
            // btnHospitales
            // 
            this.btnHospitales.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnHospitales.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHospitales.Font = new System.Drawing.Font("Microsoft YaHei UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHospitales.Image = global::SanidadEjercicio2Tablas.Properties.Resources._07b5ff2a8a2ab5dd7d29f31d5d73835e_removebg_preview_removebg_preview__3_;
            this.btnHospitales.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHospitales.Location = new System.Drawing.Point(3, 249);
            this.btnHospitales.Name = "btnHospitales";
            this.btnHospitales.Size = new System.Drawing.Size(198, 55);
            this.btnHospitales.TabIndex = 1;
            this.btnHospitales.Text = "Hospitales";
            this.btnHospitales.UseVisualStyleBackColor = false;
            this.btnHospitales.Click += new System.EventHandler(this.btnHospitales_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1279, 664);
            this.Controls.Add(this.pnFormularios);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "FrmPrincipal";
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.pnFormularios.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnHospitales;
        private System.Windows.Forms.Button btnMedicos;
        private System.Windows.Forms.Panel pnFormularios;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

